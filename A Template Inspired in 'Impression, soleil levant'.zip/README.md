Permission is hereby granted, free of charge, to any person obtaining a copy of this template and associated documentation files (the "A Template Inspired in 'Impression, soleil levant'"), to use the Template without restriction, including without limitation the rights to use, modify, merge and distribute copys of the Template, and to permit persons to whom the Template is furnished to do so, subject to the following conditions:

1. YOU MAY NOT SELL THIS TEMPLETE, or any modified version of it.

For support or inquiries, please contact lcsximenes@usp.br.